import React from 'react'

function GuestLayout() {
  return (
    <div>GuestLayout</div>
  )
}

export default GuestLayout