import React from 'react'

function PageTitle({title}) {
  return <title> {title} - Dashboard</title>
}

export default PageTitle