import React from 'react'

function Welcome() {
  return (
    <div>Welcome</div>
  )
}

export default Welcome