<?php

namespace App\Enums;

enum OrderStatusEnum{
    const PENDING = "pending";
    const ORDER = "order";
    const RECEIVED = "received";
}
