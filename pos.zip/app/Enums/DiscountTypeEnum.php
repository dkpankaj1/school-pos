<?php

namespace App\Enums;

enum DiscountTypeEnum{
    const FIXED = "fixed";
    const PERCENT = "percent";
}
