<?php

namespace App\Enums;

enum ExceptionMessage{
    const SOMETHING_WENT_WRONG = "something went wrong";
}
