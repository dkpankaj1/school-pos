<?php

namespace App\Enums;

enum PaymentStatusEnum{
    const PENDING = "pending";
    const PARTIAL = "partial";
    const PAID = "paid";
}
