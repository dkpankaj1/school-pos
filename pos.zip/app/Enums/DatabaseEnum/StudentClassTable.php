<?php

namespace App\Enums\DatabaseEnum;

enum StudentClassTable
{
    const TABLE = "student_classes";
    const NAME = "name";
    const DESCRIPTION = "description";
    const FINANCE_YEAR = "finance_year_id";

}
