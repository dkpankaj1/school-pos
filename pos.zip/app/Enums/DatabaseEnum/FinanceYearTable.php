<?php
namespace App\Enums\DatabaseEnum;

enum FinanceYearTable{
    const TABLE ="finance_years";
    const NAME ="name";
    const FROM_DATE ="from_date";
    const TO_DATE ="to_date";
    
    
}

?>