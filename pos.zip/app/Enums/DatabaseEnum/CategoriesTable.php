<?php
namespace App\Enums\DatabaseEnum;
enum CategoriesTable{
    const TABLE = "categories";
    const NAME = "name";
    const DESCRIPTION = "description";
    
    const FINANCE_YEAR = "finance_year_id";

    
}

?>