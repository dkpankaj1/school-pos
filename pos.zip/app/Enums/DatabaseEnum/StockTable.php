<?php
namespace App\Enums\DatabaseEnum;

enum StockTable
{
    const PRODUCT_ID = "product_id";
    const QUANTITY = "quantity";
    const FINANCE_YEAR = "finance_year_id";

}

