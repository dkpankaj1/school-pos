<?php
namespace App\Enums\DatabaseEnum;
enum UnitTable{
    const TABLE = "units";
    const NAME = "name";
    const SHORTNAME = "short_name";
    const DESCRIPTION = "description";    
    const FINANCE_YEAR = "finance_year_id";    
}
